This website is dedicated to my boss, JAY the KULANGOT MAN
