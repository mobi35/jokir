<?php

namespace App\Filament\Resources\BuildingResource\Widgets;

use Filament\Widgets\Widget;
use Filament\Forms\Components\Section;

use Filament\Widgets\StatsOverviewWidget\Card;

class BuildingDetailsWidget extends Widget
{

	protected static string $view = 'filament.resources.building.widgets.building-show';

	
}
