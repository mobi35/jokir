<?php

namespace App\Filament\Resources\OwnerResource\Widgets;

use Filament\Widgets\Widget;

class OwnerBuildings extends Widget
{

    protected static string $view = 'filament.resources.owner-resource.widgets.owner-buildings';


	protected ?string $maxContentWidth = 'full';


}
