
<x-filament::widget >
    <x-filament::card class="bg-red-500" >
		<h1>
		tamod de guererro
		</h1>
    </x-filament::card>
</x-filament::widget>
