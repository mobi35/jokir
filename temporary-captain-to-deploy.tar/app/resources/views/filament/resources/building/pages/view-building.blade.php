<div>

  <x-filament::page>
  <x-filament::card>



    </x-filament::card>
  </x-filament::page>

</div>